import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.io.IOException;

// Execução do robô
class RobotExecution {
    private int id;
    private String dateTime;
    private boolean success;
    private String logPath;

    public void setSuccess(boolean success) {
        this.success = success;
    }
}

// Repositório
interface RobotExecutionRepository {
    void saveExecution(RobotExecution execution);
    List<RobotExecution> getAllExecutions();

}
class RobotExecutionRepositoryImpl implements RobotExecutionRepository {
    @Override
    public void saveExecution(RobotExecution execution) {
    }

    @Override
    public List<RobotExecution> getAllExecutions() {
        return null;
    }
}

class RobotExecutionService {
    private RobotExecutionRepository repository;

    public RobotExecutionService(RobotExecutionRepository repository) {
        this.repository = repository;
    }

    public void executeRobot(String robotPath) {
        try {
            Process process = Runtime.getRuntime().exec(robotPath);
            int exitCode = process.waitFor();
            boolean success = (exitCode == 0);

            RobotExecution execution = new RobotExecution();
            execution.setSuccess(success);

            repository.saveExecution(execution);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void scheduleRobotExecution(String robotPath, String scheduleDetails) {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                executeRobot(robotPath);
            }
        }, calculateInitialDelay(scheduleDetails), 24 * 60 * 60 * 1000);

    }

    private long calculateInitialDelay(String scheduleDetails) {
        return 0;
    }
}

class RobotExecutionController {
    private RobotExecutionService service;

    public RobotExecutionController(RobotExecutionService service) {
        this.service = service;
    }

    public void scheduleRobotExecution(String robotPath, String scheduleDetails) {
        service.scheduleRobotExecution(robotPath, scheduleDetails);
    }

}

public class Main {
    public static void main(String[] args) {
        RobotExecutionRepository repository = new RobotExecutionRepositoryImpl();
        RobotExecutionService service = new RobotExecutionService(repository);
        RobotExecutionController controller = new RobotExecutionController(service);
        String robotPath = "C:\\Users\\tarso\\Downloads\\robo_info\\dist\\main\\RoboPortoDigital.exe";
        String scheduleDetails = "daily"; // Detalhes do agendamento
        controller.scheduleRobotExecution(robotPath, scheduleDetails);
    }
}